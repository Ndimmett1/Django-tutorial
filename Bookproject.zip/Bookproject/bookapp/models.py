from django.db import models

# Create your models here.
class Book(models.Model):
    # field_name = models.datatype
    isbn = models.CharField(max_length=13, unique=True)
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=100)
    category = models.CharField(max_length=50)
    no_of_pages = models.SmallIntegerField()
    publication_date = models.DateField()

    # string representation method
    def __str__(self):
        #return self.title
        # if you want the str repr to show more than one field
        return f"{self.title}"

