from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from .models import Book
from .forms import BookForm

# Create your views here.
def anynameiwant(request):
    return HttpResponse("S I w to be printed other than Django installed successfully") 

# creating a view to pull books from our db
def showbooks(request):
    allbooks = Book.objects.all()
    return render(request, "index.html", {"books": allbooks})

  # link the books object to the template (index.html)
  # return render(request, "your_template.html", {'key': object"})
  # the key is what you will use to represent all the books you got
  # the object is your book object (book_title, isbn, etc)

# WE'RE GOING TO CREATE A VIEW THAT CREATES(aDD) A NEW BOOK
def addbook(request):
    if request.method == "POST":
        bookform = BookForm(request.POST)
        if bookform.is_valid():
            bookform.save()
            return redirect("allbooks")
    else:
         bookform = BookForm()
    return render(request, "add_book.html", {"form": bookform})

def editbook(request, isbn):
    book = get_object_or_404(Book, isbn = isbn)
    if request.method == "POST":
        bookform = BookForm(request.POST, instance=book)
        if bookform.is_valid():
            bookform.save()
            return redirect("allbooks")
    else:
        bookform = BookForm(instance=book)
    return render(request, "edit_book.html", {"form": bookform})

def deletebook(request, isbn):
    book = get_object_or_404(Book, isbn = isbn)
    if request.method == "POST":
        book.delete()
        return redirect("allbooks")
    return render(request, "delete_book.html", {"book": book})