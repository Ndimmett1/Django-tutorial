from django import forms
# since we're creating our forms from our model, we need to import the model too
from .models import Book

class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        #fields = ['isbn', 'title', 'author', 'category', 'no_of_pages', 'publication_date']
        # if you want to use all fields in the model on the form you can just say
        fields = '__all__'