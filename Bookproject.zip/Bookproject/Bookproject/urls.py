"""
URL configuration for Bookproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.1/topics/http/urls/
Ex
. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from bookapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.showbooks, name = "allbooks"),
    path('add/', views.addbook, name = "addbook"),
    path('<str:isbn>/edit', views.editbook, name = "editbook"),
    path('<str:isbn>/delete', views.deletebook, name = "deletebook"),
]
